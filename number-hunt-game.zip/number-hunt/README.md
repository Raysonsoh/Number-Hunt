# NUMBER HUNT — multiplayer event game

A live Node.js + Socket.IO web game supporting 100 simultaneous participants, three elimination rounds, automatic narrowing ranges, a single fixed secret number, and random-target sudden-death tiebreakers.

## Run locally

1. Install Node.js 18 or newer.
2. In this folder, run `npm install` then `ADMIN_PIN=your-secret-pin npm start` (Windows PowerShell: `$env:ADMIN_PIN='your-secret-pin'; npm start`).
3. Visit `http://localhost:3000/?view=admin` to host, `http://localhost:3000/?view=screen` to project, and `http://localhost:3000/` to join.
4. For guests to join from their phones, deploy this project to a publicly accessible Node.js host with persistent WebSocket support (for example, Render or Railway). Configure the `ADMIN_PIN` environment variable there and use its HTTPS URL for the QR code.

## Rules

- The server randomly chooses a secret integer 1–100 once per game.
- Two progressively smaller inclusive survival ranges are generated around that number before the game begins.
- All players guess within 15 seconds. After Round 1 and 2, those whose guesses fall outside the next survival range are eliminated. If nobody qualifies, the closest submitted guess(es) to that range are rescued.
- Round 3 reveals the fixed secret. The closest guess wins. Tied closest guesses proceed to a tiebreaker.
- A new random target 1–100 is generated for each tiebreaker, hidden until guesses lock. Closest wins; repeat if still tied.
- No points are used. Admin controls opening and revealing rounds.

## Deployment cautions

- This is an MVP, not a hardened production service. All state is held in memory; restarting the server resets the game. Players who refresh their browser lose their Socket.IO identity. Deploy a single instance and avoid restarting during an event.
- Use a strong `ADMIN_PIN`. The default PIN is intended only for local testing.
- Test mobile connectivity, projector display and QR rendering on your actual venue network before use. The QR library is loaded from a CDN, so external internet access is required for QR rendering.
- To make it event-production-ready, add persistent sessions/reconnect tokens, durable storage, an authenticated organiser account, rate limiting and a reconnect-friendly UI.
